wget https://github.com/ChenyangQiQi/FateZero/releases/download/v1.0.0/attribute.zip
mkdir attribute
unzip attribute.zip -d attribute

wget https://github.com/ChenyangQiQi/FateZero/releases/download/v1.0.0/negative_reg.zip
mkdir negative_reg
unzip negative_reg.zip -d negative_reg

wget https://github.com/ChenyangQiQi/FateZero/releases/download/v1.0.0/style.zip
mkdir style
unzip style.zip -d style

wget https://github.com/ChenyangQiQi/FateZero/releases/download/v1.0.0/shape.zip
mkdir shape
unzip shape.zip -d shape


